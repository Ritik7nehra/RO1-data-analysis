"""Validate the bundled workbook and non-UI dashboard components."""

from __future__ import annotations

import json
from pathlib import Path

from charts import (
    comparison_bar_figure,
    delta_distribution_figure,
    distribution_figure,
    missingness_figure,
    paired_scatter_figure,
    trend_figure,
    visit_counts_figure,
)
from data_utils import (
    completion_rate,
    dataframe_to_excel_bytes,
    load_clinical_workbook,
    missingness_table,
    suggested_metrics,
    summary_statistics,
)


ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "data" / "R_Deidentified_R01_.xlsx"


def main() -> None:
    bundle = load_clinical_workbook(DATA_FILE.read_bytes(), DATA_FILE.name)
    data = bundle["data"]
    metrics = suggested_metrics(data)

    assert len(data) == 797, f"Expected 797 rows, found {len(data)}"
    assert data["Patient ID"].nunique() == 256, "Unexpected patient count"
    assert bundle["quality"]["Duplicate Patient-Visit Rows"] == 0
    assert set(bundle["visit_order"]) == {"V1/V1A", "V2", "V3", "V4"}
    assert metrics, "No numeric clinical metrics were detected"

    stats = summary_statistics(data, metrics)
    missingness = missingness_table(data, metrics)

    figures = [
        visit_counts_figure(bundle["visit_counts"]),
        missingness_figure(missingness),
        trend_figure(data, metrics[0], "Population mean"),
        trend_figure(data, metrics[0], "Population median", chart_type="Area"),
        distribution_figure(data, metrics[0], "Box plot"),
        distribution_figure(data, metrics[0], "Histogram"),
    ]

    pivot = data.pivot_table(
        index="Patient ID",
        columns="Visit",
        values=metrics[0],
        aggfunc="mean",
    )
    paired = pivot[["V1/V1A", "V4"]].dropna()
    figures.extend(
        [
            comparison_bar_figure(
                "V1/V1A",
                "V4",
                paired["V1/V1A"].mean(),
                paired["V4"].mean(),
                metrics[0],
            ),
            paired_scatter_figure(paired, "V1/V1A", "V4", metrics[0]),
            delta_distribution_figure(paired["V4"] - paired["V1/V1A"], metrics[0]),
        ]
    )
    for figure in figures:
        assert len(figure.to_json()) > 1000, "A Plotly figure did not serialize correctly"

    export_bytes = dataframe_to_excel_bytes(data.head(100), stats, bundle["quality"])
    assert export_bytes.startswith(b"PK"), "Excel export is not a valid XLSX container"

    report = {
        "status": "PASS",
        "workbook": DATA_FILE.name,
        "visit_rows": len(data),
        "unique_patients": data["Patient ID"].nunique(),
        "unique_patient_visits": bundle["quality"]["Unique Patient-Visits"],
        "duplicate_patient_visit_rows": bundle["quality"]["Duplicate Patient-Visit Rows"],
        "visit_order": bundle["visit_order"],
        "visit_counts": bundle["visit_counts"].to_dict(orient="records"),
        "visit_date_coverage_percent": round(bundle["quality"]["Visit Date Coverage %"], 3),
        "completion_rate_percent": round(completion_rate(data, bundle["visit_order"]), 3),
        "default_metrics": metrics,
        "longitudinal_columns": len(data.columns),
        "charts_serialized": len(figures),
        "excel_export_test": "PASS",
    }
    (ROOT / "validation_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
